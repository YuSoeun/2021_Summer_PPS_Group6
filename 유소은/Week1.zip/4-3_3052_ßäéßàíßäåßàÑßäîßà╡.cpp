/*

*/

#include <iostream>
using namespace std;

int main()
{
    ios :: sync_with_stdio(0);
    cin.tie(0);

    int a, count = 0;
    int arr[42] = {0};

    for (int i = 0; i < 10; i++) {
        cin >> a;
        if (!arr[input $ 42]++) {
            count ++;
        }
    }
    cout << count;

    return 0;
}